from model import *
import torch
from Params import args
from DataHandler import DataHandler
from engine import inference
import pandas as pd
import pickle
import matplotlib.pyplot as plt

def process_csv(f):
    offenseMap = {
        0: 'Theft From Motor Vehicle',
        1: 'Burglary/Breaking & Entering',
        2: 'Destruction/Damage/Vandalism of Property',
        3: 'All Other Larceny'
    }
    cleaned_df = df.drop(['Report Number', 'Offense ID', 'Group A B', 'Crime Against Category', "Offense Start DateTime", "Offense End DateTime", "Precinct", "Sector", "Beat", "Offense Parent Group", "Offense Code", "MCPP", "100 Block Address"], axis=1)
    cleaned_df = cleaned_df[cleaned_df['Report DateTime'].notna()]
    cleaned_df = cleaned_df[cleaned_df['Offense'].notna()]
    cleaned_df = cleaned_df[cleaned_df['Longitude'].notna()]

    epsilon_dist = 10
    cleaned_df = cleaned_df[cleaned_df['Offense'].isin(offenseMap.values())]
    cleaned_df = cleaned_df[abs(cleaned_df.Latitude - 47) < epsilon_dist]
    cleaned_df = cleaned_df[abs(abs(cleaned_df.Longitude) - 122) < epsilon_dist]
    cleaned_df.to_csv('cleaned.csv', header=False, index=False)

    offenseSet = set()
    latSet = set()
    lonSet = set()
    timeSet = set()
    data = []
    
    with open('./cleaned_spd.csv', 'r') as fs:
        fs.readline()
        for line in fs:
            arr = line.strip().split(',')

            timeArray = time.strptime(arr[0], '%m/%d/%Y %I:%M:%S %p')
            timestamp = time.mktime(timeArray)
            offense = offenseMap[arr[1]]
            lat = float(arr[2])
            lon = float(arr[3])
    latSet.add(lat)
    lonSet.add(lon)
    timeSet.add(timestamp)
    offenseSet.add(offense)

    data.append({
        'time': timestamp,
        'offense': offense,
        'lat': lat,
        'lon': lon
    })
            
    minLat = min(latSet)
    minLon = min(lonSet)
    maxLat = max(latSet)
    maxLon = max(lonSet)
    latDiv = 111 / 3 #1
    lonDiv = 84 / 3 #1
    latNum = int((maxLat - minLat) * latDiv) + 1
    lonNum = int((maxLon - minLon) * lonDiv) + 1
    minDate = min(timeset)
    maxDate = max(timeset)


    dataTensor = np.zeros((latNum, lonNum, (maxDate - minDate) // 86400 + 1, len(offenseSet)))
    
    for i in range(len(data)):
        tup = data[i]
        temT = time.localtime(tup['time'])
        row = int((tup['lat'] - minLat) * latDiv)
        col = int((tup['lon'] - minLon) * lonDiv)
        offense = tup['offense']
        dataTensor[row][col][day][offense] += 1
        
    pickle.dump(dataTensor, 'tst.pkl')



def main():
    device = torch.device('cpu')
    model = STHSL()
    model.to(device)
    model.load_state_dict(torch.load(args.checkpoint))
    model.eval()
    while True:
        # read in path to data csv from stdin
        data_csv = input()

        # process it and convert to tensor
        process_csv(data_csv)
        handler = DataHandler()

        # run model
        # with torch.no_grad():
        #     reses = t
        
        # output results of inference to stdout
        
