import time
import numpy as np
import pickle
import pandas as pd


df = pd.read_csv("SPD_Crime_Data__2008-Present.csv")
cleaned_df = df.drop(['Report Number', 'Offense ID', 'Group A B', 'Crime Against Category', "Offense Start DateTime", "Offense End DateTime", "Precinct", "Sector", "Beat", "Offense Parent Group", "Offense Code", "MCPP", "100 Block Address"], axis=1)
cleaned_df = cleaned_df[cleaned_df['Report DateTime'].notna()]
cleaned_df = cleaned_df[cleaned_df['Offense'].notna()]
cleaned_df = cleaned_df[cleaned_df['Longitude'].notna()]
vc = cleaned_df['Offense'].value_counts()[:4].index.to_list()
cleaned_df = cleaned_df[cleaned_df['Offense'].isin(vc)]
cleaned_df.head()
epsilon_dist = 10
cleaned_df = cleaned_df[abs(cleaned_df.Latitude - 47) < epsilon_dist]
cleaned_df = cleaned_df[abs(abs(cleaned_df.Longitude) - 122) < epsilon_dist]
l = list(set(cleaned_df['Offense']))
offenseMap = dict(map(lambda x: (x, l.index(x)), l))
print(f'Latitude: {min(cleaned_df["Latitude"])} to {max(cleaned_df["Latitude"])}')
print(f'Longitude: {min(cleaned_df["Longitude"])} to {max(cleaned_df["Longitude"])}')
print(offenseMap)

cleaned_df.to_csv('cleaned_spd.csv', header=False, index=False)

offenseSet = set()
latSet = set()
lonSet = set()
timeSet = set()
data = []

with open('./cleaned_spd.csv', 'r') as fs:
	fs.readline()
	for line in fs:
		arr = line.strip().split(',')

		timeArray = time.strptime(arr[0], '%m/%d/%Y %I:%M:%S %p')
		timestamp = time.mktime(timeArray)
		offense = offenseMap[arr[1]]
		lat = float(arr[2])
		lon = float(arr[3])

		latSet.add(lat)
		lonSet.add(lon)
		timeSet.add(timestamp)
		offenseSet.add(offense)

		data.append({
			'time': timestamp,
			'offense': offense,
			'lat': lat,
			'lon': lon
		})
print('Length of data', len(data), '\n')
print('Offense:', offenseSet, '\n')
print('Latitude:', min(latSet), max(latSet))
print('Longtitude:', min(lonSet), max(lonSet))
print('Latitude:', min(latSet), max(latSet), (max(latSet) - min(latSet)) / (1 / 111), '\n')
print('Longtitude:', min(lonSet), max(lonSet), (max(lonSet) - min(lonSet)) / (1 / 84), '\n')
print('Time:')


minLat = min(latSet)
minLon = min(lonSet)
maxLat = max(latSet)
maxLon = max(lonSet)
latDiv = 111 / 3 #1
lonDiv = 84 / 3 #1
latNum = int((maxLat - minLat) * latDiv) + 1
lonNum = int((maxLon - minLon) * lonDiv) + 1
trnTensor = np.zeros((latNum, lonNum, 4063, len(offenseSet)))
valTensor = np.zeros((latNum, lonNum, 731, len(offenseSet)))
tstTensor = np.zeros((latNum, lonNum, 731, len(offenseSet)))
for i in range(len(data)):
	tup = data[i]
	temT = time.localtime(tup['time'])
	if temT.tm_year < 2019 or (temT.tm_year == 2019 and (temT.tm_mon < 2 or (temT.tm_mon == 2 and temT.tm_mday <= 15))):
		day = temT.tm_yday + (0 if temT.tm_year % 4 == 0 else 366) - 1
		tensor = trnTensor
	elif temT.tm_year < 2021 or (temT.tm_year == 2021 and (temT.tm_mon < 2 or (temT.tm_mon == 2 and temT.tm_mday <= 15))):
		day = temT.tm_yday + (0 if temT.tm_year % 4 == 0 else 366) - 1
		tensor = valTensor
	else:
		day = temT.tm_yday + (0 if temT.tm_year % 4 == 0 else 366) - 1
		tensor = tstTensor

	row = int((tup['lat'] - minLat) * latDiv)
	col = int((tup['lon'] - minLon) * lonDiv)
	offense = tup['offense']
	tensor[row][col][day][offense] += 1

names = ['trn.pkl', 'val.pkl', 'tst.pkl']
tensors = [trnTensor, valTensor, tstTensor]
for i in range(len(names)):
	with open('Datasets/CHI_crime/' + names[i], 'wb') as fs:
		pickle.dump(tensors[i], fs)
